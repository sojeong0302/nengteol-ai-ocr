import { createContext } from "react";
export const DiaryStateContext = createContext([]);
