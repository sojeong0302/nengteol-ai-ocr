import FoodUpload from "../components/FoodUpload/FoodUpload";

export default function CartUpload() {
    return (
        <div className="space-y-6">
            <FoodUpload />
        </div>
    );
}
