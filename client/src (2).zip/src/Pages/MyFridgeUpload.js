import FoodUpload from "../components/FoodUpload/FoodUpload";

export default function MyFridgeUpload() {
    return (
        <div className="space-y-6">
            <FoodUpload />
        </div>
    );
}
