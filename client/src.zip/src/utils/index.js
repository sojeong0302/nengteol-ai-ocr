export const createPageUrl = (pageName) => {
  return `/${pageName}`;
};