export default function Community() {
    return <div className="space-y-6">서비스 구현중</div>;
}
