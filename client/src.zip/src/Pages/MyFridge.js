import React, { useState, useEffect } from "react";
import { FoodItem } from "../entities/FoodItem";
import { Tabs, TabsContent, TabsTrigger } from "../components/ui/tabs";
import { Refrigerator, Upload, AlertTriangle, Timer, Leaf } from "lucide-react";
import { differenceInDays, parseISO } from "date-fns";
import { AnimatePresence } from "framer-motion";
import FoodItemCard from "../components/fridge/FoodItemCard";
import ReceiptUpload from "../components/fridge/ReceiptUpload";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function MyFridge() {
    const [foodItems, setFoodItems] = useState([]);
    const [showUpload, setShowUpload] = useState(false);
    const [loading, setLoading] = useState(true);
    const [food, setFood] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        loadFoodItems();
    }, []);

    const loadFoodItems = async () => {
        try {
            const items = await FoodItem.filter({ status: "active" }, "-expiry_date");
            setFoodItems(items);
        } catch (error) {
            console.error("식재료 로딩 실패:", error);
        }
        setLoading(false);
    };

    const handleUseItem = async (item) => {
        await FoodItem.update(item.id, { status: "used" });
        loadFoodItems();
    };

    const handleDeleteItem = async (item) => {
        await FoodItem.delete(item.id);
        loadFoodItems();
    };

    const categorizeByExpiry = (items) => {
        const today = new Date();
        return items.reduce(
            (acc, item) => {
                const daysUntilExpiry = differenceInDays(parseISO(item.expiry_date), today);

                if (daysUntilExpiry < 0) {
                    acc.expired.push(item);
                } else if (daysUntilExpiry <= 2) {
                    acc.urgent.push(item);
                } else if (daysUntilExpiry <= 5) {
                    acc.soon.push(item);
                } else {
                    acc.fresh.push(item);
                }
                return acc;
            },
            { urgent: [], soon: [], fresh: [], expired: [] }
        );
    };

    const categorized = categorizeByExpiry(foodItems);
    const urgentCount = categorized.urgent.length;
    const soonCount = categorized.soon.length;

    if (loading) {
        return (
            <div className="page-content">
                <div className="space-y-4">
                    <div className="h-8 bg-gray-200 rounded w-1/3 animate-pulse"></div>
                    <div className="h-32 bg-gray-200 rounded animate-pulse"></div>
                    <div className="space-y-3">
                        {[1, 2, 3].map((i) => (
                            <div key={i} className="h-20 bg-gray-200 rounded animate-pulse"></div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header
            <div className="page-header">
                <div className="flex justify-between items-start">
                    <div className="flex gap-3">
                        <div className="page-icon">
                            <Refrigerator className="w-6 h-6 text-white" />
                        </div>
                        <div>
                            <h1 className="text-2xl font-bold text-gray-800">내 냉장고</h1>
                            <p className="text-gray-500 text-sm">보유 식재료 {foodItems.length}개</p>
                        </div>
                    </div>

                    <button
                        onClick={() => setShowUpload(!showUpload)}
                        className="btn btn-outline flex items-center gap-2"
                    >
                        <Upload className="w-4 h-4" />
                        영수증 업로드
                    </button>
                </div>
            </div>
            {/* Alert Cards */}
            {(urgentCount > 0 || soonCount > 0) && (
                <div className="grid grid-cols-2 gap-4">
                    <div className="card bg-red-50 border-red-200" onClick={() => navigate("/MyFridgeUpload")}>
                        <div className="flex items-center gap-2 mb-2">
                            <div className="cursor-pointer font-semibold text-red-800">등록하기</div>
                        </div>
                        <p className="text-red-700">새로운 재료를 등록해주세요.</p>
                    </div>
                    {urgentCount > 0 && (
                        <div className="card bg-red-50 border-red-200">
                            <div className="flex items-center gap-2 mb-2">
                                <AlertTriangle className="w-5 h-5 text-red-600" />
                                <h3 className="font-semibold text-red-800">긴급! 빨리 소진하세요</h3>
                            </div>
                            <p className="text-red-700">{urgentCount}개 식재료가 곧 상할 예정입니다.</p>
                        </div>
                    )}
                </div>
            )}
            {/* Upload Component */}
            {showUpload && (
                <ReceiptUpload
                    onUploadComplete={() => {
                        setShowUpload(false);
                        loadFoodItems();
                    }}
                />
            )}
            {/* Tabs */}
            <Tabs defaultValue="urgent" className="w-full">
                <div className="tabs-list">
                    <TabsTrigger value="urgent" className="tab-trigger flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4" />
                        고기
                        {urgentCount > 0 && <span className="badge badge-red">{urgentCount}</span>}
                    </TabsTrigger>
                    <TabsTrigger value="soon" className="tab-trigger flex items-center gap-2">
                        <Timer className="w-4 h-4" />
                        해산물
                        {soonCount > 0 && <span className="badge badge-yellow">{soonCount}</span>}
                    </TabsTrigger>
                    <TabsTrigger value="fresh" className="tab-trigger flex items-center gap-2">
                        <Leaf className="w-4 h-4" />
                        유제품
                    </TabsTrigger>
                    <TabsTrigger value="fresh" className="tab-trigger flex items-center gap-2">
                        <Leaf className="w-4 h-4" />
                        음료
                    </TabsTrigger>
                    <TabsTrigger value="fresh" className="tab-trigger flex items-center gap-2">
                        <Leaf className="w-4 h-4" />
                        채소
                    </TabsTrigger>
                    <TabsTrigger value="fresh" className="tab-trigger flex items-center gap-2">
                        <Leaf className="w-4 h-4" />
                        과일
                    </TabsTrigger>
                </div>

                <TabsContent value="urgent" className="mt-6 space-y-4">
                    <AnimatePresence>
                        {categorized.urgent.map((item) => (
                            <FoodItemCard key={item.id} item={item} onUse={handleUseItem} onDelete={handleDeleteItem} />
                        ))}
                    </AnimatePresence>
                    {categorized.urgent.length === 0 && (
                        <div className="text-center py-12 card">
                            <AlertTriangle className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                            <p className="text-gray-500">긴급하게 소진할 식재료가 없습니다 👍</p>
                        </div>
                    )}
                </TabsContent>

                <TabsContent value="soon" className="mt-6 space-y-4">
                    <AnimatePresence>
                        {categorized.soon.map((item) => (
                            <FoodItemCard key={item.id} item={item} onUse={handleUseItem} onDelete={handleDeleteItem} />
                        ))}
                    </AnimatePresence>
                    {categorized.soon.length === 0 && (
                        <div className="text-center py-12 card">
                            <Timer className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                            <p className="text-gray-500">주의할 식재료가 없습니다</p>
                        </div>
                    )}
                </TabsContent>

                <TabsContent value="fresh" className="mt-6 space-y-4">
                    <AnimatePresence>
                        {categorized.fresh.map((item) => (
                            <FoodItemCard key={item.id} item={item} onUse={handleUseItem} onDelete={handleDeleteItem} />
                        ))}
                    </AnimatePresence>
                    {categorized.fresh.length === 0 && (
                        <div className="text-center py-12 card">
                            <Leaf className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                            <p className="text-gray-500">신선한 식재료가 없습니다</p>
                        </div>
                    )}
                </TabsContent>

                <TabsContent value="expired" className="mt-6 space-y-4">
                    <AnimatePresence>
                        {categorized.expired.map((item) => (
                            <FoodItemCard key={item.id} item={item} onUse={handleUseItem} onDelete={handleDeleteItem} />
                        ))}
                    </AnimatePresence>
                    {categorized.expired.length === 0 && (
                        <div className="text-center py-12 card">
                            <AlertTriangle className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                            <p className="text-gray-500">만료된 식재료가 없습니다</p>
                        </div>
                    )}
                </TabsContent>
            </Tabs>
        </div>
    );
}
