import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Trash2, AlertTriangle, CheckCircle2, Snowflake, Package } from "lucide-react";
import { format, differenceInDays, parseISO } from "date-fns";
import { ko } from "date-fns/locale";
import axios from "axios";

const categoryIcons = {
    produce: "🥬",
    meat: "🥩",
    dairy: "🥛",
    pantry: "🍝",
    frozen: "🧊",
    other: "📦",
};

const categoryColors = {
    produce: "bg-green-100 text-green-700 border-green-200",
    meat: "bg-red-100 text-red-700 border-red-200",
    dairy: "bg-blue-100 text-blue-700 border-blue-200",
    pantry: "bg-yellow-100 text-yellow-700 border-yellow-200",
    frozen: "bg-cyan-100 text-cyan-700 border-cyan-200",
    other: "bg-gray-100 text-gray-700 border-gray-200",
};

export default function FoodItemCard({ item, onUse, onDelete }) {
    const today = new Date();
    const expiryDate = parseISO(item.expiry_date);
    const daysUntilExpiry = differenceInDays(expiryDate, today);

    const getExpiryStatus = () => {
        if (daysUntilExpiry < 0) return { status: "expired", color: "bg-red-500", text: "유통기한 지남" };
        if (daysUntilExpiry === 0) return { status: "today", color: "bg-orange-500", text: "오늘까지" };
        if (daysUntilExpiry <= 2) return { status: "urgent", color: "bg-red-400", text: `D-${daysUntilExpiry}` };
        if (daysUntilExpiry <= 5) return { status: "warning", color: "bg-orange-400", text: `D-${daysUntilExpiry}` };
        return { status: "good", color: "bg-green-400", text: `D-${daysUntilExpiry}` };
    };

    const expiryInfo = getExpiryStatus();

    useEffect(() => {
        // 컴포넌트가 처음 렌더링될 때 실행
        const fetchData = async () => {
            try {
                const res = await axios.get("http://localhost:5000/api/foods/0");
                console.log("받은 데이터:", res.data);
                setFood(res.data);
            } catch (err) {
                console.error("데이터 가져오기 실패:", err);
            }
        };

        fetchData();
    }, []); // [] → 최초 1회만 실행

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.2 }}
        >
            <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0 bg-white/80 backdrop-blur-sm">
                <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3 flex-1">
                            <div className="text-2xl">{categoryIcons[item.category]}</div>
                            <div className="flex-1 min-w-0">
                                <h3 className="font-semibold text-gray-800 text-lg truncate">{item.name}</h3>
                                <div className="flex items-center gap-2 mt-1">
                                    <Badge variant="outline" className={categoryColors[item.category]}>
                                        {item.quantity} {item.unit}
                                    </Badge>
                                    <div className="flex items-center gap-1 text-sm text-gray-500">
                                        {item.storage_type === "freezer" && <Snowflake className="w-3 h-3" />}
                                        {item.storage_type === "pantry" && <Package className="w-3 h-3" />}
                                        <Calendar className="w-3 h-3" />
                                        <span>{format(expiryDate, "MM/dd", { locale: ko })}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="flex flex-col items-end gap-2">
                            <Badge className={`${expiryInfo.color} text-white border-0 font-semibold px-2 py-1`}>
                                {expiryInfo.text}
                            </Badge>

                            <div className="flex gap-1">
                                <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => onUse(item)}
                                    className="h-8 px-2 bg-green-50 hover:bg-green-100 border-green-200 text-green-700"
                                >
                                    <CheckCircle2 className="w-3 h-3" />
                                </Button>
                                <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => onDelete(item)}
                                    className="h-8 px-2 bg-red-50 hover:bg-red-100 border-red-200 text-red-700"
                                >
                                    <Trash2 className="w-3 h-3" />
                                </Button>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </motion.div>
    );
}
