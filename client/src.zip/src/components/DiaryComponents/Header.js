import "./Header.css";

const Header = ({ title, leftChild, rightChild }) => {
    return (
        <div className="Header">
            <div className="">{leftChild}</div>
            <div className="">{title}</div>
            <div className="header_right">{rightChild}</div>
        </div>
    );
};

export default Header;
