import React from "react";
import { motion } from "framer-motion";
import { differenceInDays, parseISO, format } from "date-fns";
import { ko } from "date-fns/locale";
import { Clock, Trash2, CheckCircle, AlertTriangle, Timer } from "lucide-react";

const FoodItemCard = ({ item, onUse, onDelete }) => {
    const daysUntilExpiry = differenceInDays(parseISO(item.expiry_date), new Date());

    const getExpiryStatus = (days) => {
        if (days < 0) return { color: "badge-red", icon: AlertTriangle, text: "만료됨" };
        if (days <= 2) return { color: "badge-red", icon: AlertTriangle, text: "긴급" };
        if (days <= 5) return { color: "badge-yellow", icon: Timer, text: "주의" };
        return { color: "badge-green", icon: Clock, text: "신선" };
    };

    const status = getExpiryStatus(daysUntilExpiry);
    const StatusIcon = status.icon;

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="card"
        >
            <div className="flex items-center justify-between">
                <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-lg text-gray-800">{item.name}</h3>
                        <span className={`badge ${status.color} flex items-center gap-1`}>
                            <StatusIcon className="w-3 h-3" />
                            {status.text}
                        </span>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="badge badge-gray">{item.category}</span>
                        <span>
                            {item.quantity} {item.unit}
                        </span>
                        <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {format(parseISO(item.expiry_date), "MM/dd", { locale: ko })}
                        </span>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <button
                        onClick={() => onUse(item)}
                        className="btn btn-outline btn-sm flex items-center gap-2 text-green-600 hover:bg-green-50"
                    >
                        <CheckCircle className="w-4 h-4" />
                        추가
                    </button>
                    <button
                        onClick={() => onDelete(item)}
                        className="btn btn-outline btn-sm flex items-center gap-2 text-red-600 hover:bg-red-50"
                    >
                        <CheckCircle className="w-4 h-4" />
                        사용
                    </button>
                </div>
            </div>
        </motion.div>
    );
};

export default FoodItemCard;
